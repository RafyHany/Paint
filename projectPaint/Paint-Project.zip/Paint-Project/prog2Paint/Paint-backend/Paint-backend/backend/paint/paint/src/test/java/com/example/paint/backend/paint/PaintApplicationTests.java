package com.example.paint.backend.paint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaintApplicationTests {

	@Test
	void contextLoads() {
	}

}
