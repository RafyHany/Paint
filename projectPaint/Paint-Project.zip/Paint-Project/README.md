# Paint
 web based application for microsoft paint 

note: if vue is not running, please install konva dependencies inside vscode terminal,
 Or you can create new project and copy all content of app.vue and hello world.vue to your new project
